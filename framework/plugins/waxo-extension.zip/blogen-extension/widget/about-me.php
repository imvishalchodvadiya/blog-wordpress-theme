<?php
add_action('widgets_init', 'blogen_aboout_me_social_load_widgets');

function blogen_aboout_me_social_load_widgets() {
    register_widget('Blogen_About_Me_Widget');
}

class Blogen_About_Me_Widget extends WP_Widget {

    public function __construct() {

        $widget_ops = array('classname' => 'widget_about_me', 'description' => esc_html__('Add About Me', 'blogen'));

        $control_ops = array('id_base' => 'blogen-about-me-widget');

        parent::__construct('blogen-about-me-widget', esc_html__('Blogen : About Me', 'blogen'), $widget_ops, $control_ops);
    }

    function widget($args, $instance) {
        extract($args);
        $title = apply_filters('widget_title', $instance['title']);
        $author_name = apply_filters('widget_title', $instance['author_name']);
        $author_img = apply_filters('widget_title', $instance['author_img']);
        $author_desc = apply_filters('widget_title', $instance['author_desc']);
        $author_readmore = apply_filters('widget_title', $instance['author_readmore']);
         ?>
            <?php  echo $args['before_widget'];
            if ( ! empty( $title ) ) {
                echo $args['before_title'] . $title . $args['after_title'];
            } ?>
            <div class="text-center">
                <?php if ($author_img) : ?><img src="<?php echo $author_img; ?>" alt="About Me" class="rounded-circle"><?php endif; ?>
                <div class="about-content">
                    <a href="<?php echo $author_readmore; ?>" class="btn about-name btn-gradient-cate-info"><?php echo $author_name; ?></a>
                    <?php if ($author_desc) : ?><p class="mb-0"><?php echo $author_desc; ?></p><?php endif; ?>    
                </div>
            </div>
        <?php echo $args['after_widget'];
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;

        $instance['title'] = strip_tags($new_instance['title']);
        $instance['author_name'] = $new_instance['author_name'];
        $instance['author_img'] = $new_instance['author_img'];
        $instance['author_desc'] = $new_instance['author_desc'];
        $instance['author_readmore'] = $new_instance['author_readmore'];
        return $instance;
    }

    function form($instance) {
        $defaults = array('title' => esc_html__('About Me', 'blogen'),'author_name' => esc_html__('MIA PARKER', 'blogen'),'author_img' => '#','author_desc' => 'Quis vero phasellus hac nullam, in quam vitae duis adipiscing mauris leo, laoreet eget at quis, ante vestibulum vivamus vel. Sapien lobortis, eget orci purus amet pede, consectetur neque risus.','author_readmore' => '#');
        $instance = wp_parse_args((array) $instance, $defaults); ?>

        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <strong><?php echo esc_html__('Title', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php if (isset($instance['title'])) echo $instance['title']; ?>" />
            </label>
        </p>
		
        <p>
            <label for="<?php echo $this->get_field_id('author_name'); ?>">
                <strong><?php echo esc_html__('Author Name', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('author_name'); ?>" name="<?php echo $this->get_field_name('author_name'); ?>" value="<?php if (isset($instance['author_name'])) echo $instance['author_name']; ?>" />
            </label>
        </p>

		<p>
            <label for="<?php echo $this->get_field_id('author_img'); ?>">
                <strong><?php echo esc_html__('Author Image URL', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('author_img'); ?>" name="<?php echo $this->get_field_name('author_img'); ?>" value="<?php if (isset($instance['author_img'])) echo $instance['author_img']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('author_desc'); ?>">
                <strong><?php echo esc_html__('Descriptions', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('author_desc'); ?>" name="<?php echo $this->get_field_name('author_desc'); ?>" value="<?php if (isset($instance['author_desc'])) echo $instance['author_desc']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('author_readmore'); ?>">
                <strong><?php echo esc_html__('Read More Links', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('author_readmore'); ?>" name="<?php echo $this->get_field_name('author_readmore'); ?>" value="<?php if (isset($instance['author_readmore'])) echo $instance['author_readmore']; ?>" />
            </label>
        </p>
    <?php
    }
}
?>