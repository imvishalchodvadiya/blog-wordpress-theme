<?php
class wpb_recent_post extends WP_Widget
{
    function __construct()
    {
        $widget_ops = array('classname' => 'widget_recent_entries_custom', 'description' =>"The most popular post" );
        parent::__construct('latest-posts', 'Blogen : Popular Posts', $widget_ops);
        $this->alt_option_name = 'widget_recent_entries_custom';

        add_action('save_post', array($this, 'flush_widget_cache'));
        add_action('deleted_post', array($this, 'flush_widget_cache'));
        add_action('switch_theme', array($this, 'flush_widget_cache'));
    }
    function widget($args, $instance)
    {
        $cache = wp_cache_get('widget_recent_posts', 'widget');

        if (!is_array($cache))
            $cache = array();

        if (!isset($args['widget_id']))
            $args['widget_id'] = $this->id;

        if (isset($cache[$args['widget_id']])) {
            echo $cache[$args['widget_id']];
            return;
        }

        ob_start();
        extract($args);

        $title = (!empty($instance['title'])) ? $instance['title'] :'Popular Posts';
        $title = apply_filters('widget_title', $title, $instance, $this->id_base);
        $number = (!empty($instance['number'])) ? absint($instance['number']) : 3;
        if (!$number)
            $number = 3;
        $r = new WP_Query(apply_filters('widget_posts_args', array('posts_per_page' => $number, 'no_found_rows' => true, 'post_status' => 'publish', 'ignore_sticky_posts' => true)));
        if ($r->have_posts()) :
            ?>

            <?php  echo $args['before_widget'];
            if ( ! empty( $title ) ) {
                echo $args['before_title'] . $title . $args['after_title'];
            } ?>
            
                <?php while ($r->have_posts()) : $r->the_post(); ?>
                    <div class="polupar-post-item mb-30">
                        <?php if ( has_post_thumbnail() ) { ?>
                            <!-- img src="<?php //echo esc_url($thumbail); ?>" class="mb-20" alt="popular-post" -->
                                <?php the_post_thumbnail('post-thumbnail'); ?>
                        <?php } ?>
                        <h6>
                            <a href="<?php esc_url(the_permalink()); ?>">
                                    <?php $content = get_the_title(); /* or you can use get_the_title() */
                                    $getlength = strlen($content);
                                    $thelength = 25;
                                    echo substr($content, 0, $thelength);
                                    if ($getlength > $thelength) echo "..."; ?>
                                </a>
                            </h6>
                            <p class="mb-0 text-dim"><?php echo the_time('F j, Y'); ?></p>
                    </div> 
                <?php endwhile; ?>            
           <?php echo $args['after_widget']; ?>

            <?php 
			// Reset the global $the_post as this query will have stomped on it
            wp_reset_postdata();

        endif;

        $cache[$args['widget_id']] = ob_get_flush();
        wp_cache_set('widget_recent_posts', $cache, 'widget');
    }

    function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int)$new_instance['number'];
        $this->flush_widget_cache();

        $alloptions = wp_cache_get('alloptions', 'options');
        if (isset($alloptions['widget_Latest_entries']))
            delete_option('widget_Latest_entries');

        return $instance;
    }

    function flush_widget_cache()
    {
        wp_cache_delete('widget_recent_posts', 'widget');
    }

    function form($instance)
    {
        $title = isset($instance['title']) ? esc_attr($instance['title']) : '';
        $number = isset($instance['number']) ? absint($instance['number']) : 3;
        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
                   name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>"/></p>

        <p><label for="<?php echo $this->get_field_id('number'); ?>">Number of posts to show:</label>
            <input id="<?php echo $this->get_field_id('number'); ?>"
                   name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>"
                   size="3"/></p>

        <?php
    }
}

// Register and load the widget
function wpb_recent_post_widget()
{
    register_widget('wpb_recent_post');
}

add_action('widgets_init', 'wpb_recent_post_widget');