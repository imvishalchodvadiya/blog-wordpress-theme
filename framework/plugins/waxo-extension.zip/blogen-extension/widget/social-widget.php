<?php
add_action('widgets_init', 'blogen_social_load_widgets');

function blogen_social_load_widgets() {
    register_widget('Blogen_Social_Widget');
}

class Blogen_Social_Widget extends WP_Widget {

    public function __construct() {

        $widget_ops = array('classname' => 'widget-follows', 'description' => esc_html__('Add Social Links', 'blogen'));

        $control_ops = array('id_base' => 'blogen-social-widget');

        parent::__construct('blogen-social-widget', esc_html__('Blogen : Social', 'blogen'), $widget_ops, $control_ops);
    }

    function widget($args, $instance) {
        extract($args);
        $title = apply_filters('widget_title', $instance['title']);
        $facebook_link = apply_filters('widget_title', $instance['facebook_link']);
        $twitter_link = apply_filters('widget_title', $instance['twitter_link']);
		$instagram_link = apply_filters('widget_title', $instance['instagram_link']);
        $google_plus_link = apply_filters('widget_title', $instance['google_plus_link']);        
		$linkedin_link = apply_filters('widget_title', $instance['linkedin_link']);
		$layout = (isset($instance['layout']) && $instance['layout']) ? $instance['layout'] : 'onlyicon';
		
         ?>
            <?php  echo $args['before_widget'];
            if ( ! empty( $title ) ) {
                echo $args['before_title'] . $title . $args['after_title'];
            } ?>
			<?php if ($layout == 'onlyicon') { ?>
				<div class="widget-content">
					<ul class="list-inline social text-center mb-0">
						<?php if ($facebook_link) : ?><li class="list-inline-item"><a href="<?php echo $facebook_link; ?>" class="social-icon"><i class="mdi mdi-facebook"></i></a></li><?php endif; ?>
						<?php if ($twitter_link) : ?><li class="list-inline-item"><a href="<?php echo $twitter_link; ?>" class="social-icon"><i class="mdi mdi-twitter"></i></a></li><?php endif; ?>
						<?php if ($instagram_link) : ?><li class="list-inline-item"><a href="<?php echo $instagram_link; ?>" class="social-icon"><i class="mdi mdi-instagram"></i></a></li><?php endif; ?>            
						<?php if ($google_plus_link) : ?><li class="list-inline-item"><a href="<?php echo $google_plus_link; ?>" class="social-icon"><i class="mdi mdi-google-plus"></i></a></li><?php endif; ?>
						<?php if ($linkedin_link) : ?><li class="list-inline-item"><a href="<?php echo $linkedin_link; ?>" class="social-icon"><i class="mdi mdi-linkedin"></i></a></li><?php endif; ?>
					</ul>
				</div>
			<?php } else { ?>
				<div class="widget-content">
					<ul class="list-inline social icon-with-text text-center mb-0">
						<?php if ($facebook_link) : ?><li class="list-inline-item"><a href="<?php echo $facebook_link; ?>" class="social-icon"><i class="mdi mdi-facebook"></i> Facebook</a></li><?php endif; ?>
						<?php if ($twitter_link) : ?><li class="list-inline-item"><a href="<?php echo $twitter_link; ?>" class="social-icon"><i class="mdi mdi-twitter"></i> Twitter</a></li><?php endif; ?>
						<?php if ($instagram_link) : ?><li class="list-inline-item"><a href="<?php echo $instagram_link; ?>" class="social-icon"><i class="mdi mdi-instagram"></i> Instagram</a></li><?php endif; ?>
						<?php if ($google_plus_link) : ?><li class="list-inline-item"><a href="<?php echo $google_plus_link; ?>" class="social-icon"><i class="mdi mdi-google-plus"></i> Google +</a></li><?php endif; ?>
						<?php if ($linkedin_link) : ?><li class="list-inline-item"><a href="<?php echo $linkedin_link; ?>" class="social-icon"><i class="mdi mdi-linkedin"></i> LinkedIn</a></li><?php endif; ?>
					</ul>
				</div> 
			<?php } ?>
        <?php echo $args['after_widget'];
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;

        $instance['title'] = strip_tags($new_instance['title']);
        $instance['facebook_link'] = $new_instance['facebook_link'];
        $instance['twitter_link'] = $new_instance['twitter_link'];
		$instance['instagram_link'] = $new_instance['instagram_link'];
        $instance['google_plus_link'] = $new_instance['google_plus_link'];        
        $instance['linkedin_link'] = $new_instance['linkedin_link'];
		$instance['layout'] = $new_instance['layout'];
        return $instance;
    }

    function form($instance) {
        $defaults = array('title' => esc_html__('Social Links', 'blogen'),'facebook_link' => '#','twitter_link' => '#','google_plus_link' => '#','instagram_link' => '#','linkedin_link' => '#');
        $instance = wp_parse_args((array) $instance, $defaults); ?>

        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <strong><?php echo esc_html__('Title', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php if (isset($instance['title'])) echo $instance['title']; ?>" />
            </label>
        </p>
		
		<p>
            <label for="<?php echo $this->get_field_id('facebook_link'); ?>">
                <strong><?php echo esc_html__('Facebook Links', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('facebook_link'); ?>" name="<?php echo $this->get_field_name('facebook_link'); ?>" value="<?php if (isset($instance['facebook_link'])) echo $instance['facebook_link']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('twitter_link'); ?>">
                <strong><?php echo esc_html__('Twitter Links', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('twitter_link'); ?>" name="<?php echo $this->get_field_name('twitter_link'); ?>" value="<?php if (isset($instance['twitter_link'])) echo $instance['twitter_link']; ?>" />
            </label>
        </p>
		
		<p>
            <label for="<?php echo $this->get_field_id('instagram_link'); ?>">
                <strong><?php echo esc_html__('Instagram Links', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('instagram_link'); ?>" name="<?php echo $this->get_field_name('instagram_link'); ?>" value="<?php if (isset($instance['instagram_link'])) echo $instance['instagram_link']; ?>" />
            </label>
        </p>
		
        <p>
            <label for="<?php echo $this->get_field_id('google_plus_link'); ?>">
                <strong><?php echo esc_html__('Google Plus Links', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('google_plus_link'); ?>" name="<?php echo $this->get_field_name('google_plus_link'); ?>" value="<?php if (isset($instance['google_plus_link'])) echo $instance['google_plus_link']; ?>" />
            </label>
        </p>        

        <p>
            <label for="<?php echo $this->get_field_id('linkedin_link'); ?>">
                <strong><?php echo esc_html__('LinkedIn Links', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('linkedin_link'); ?>" name="<?php echo $this->get_field_name('linkedin_link'); ?>" value="<?php if (isset($instance['linkedin_link'])) echo $instance['linkedin_link']; ?>" />
            </label>
        </p>
		
		<p>
            <label for="<?php echo $this->get_field_id('layout'); ?>">
                <strong><?php _e('Layout Type', 'blogen') ?> :</strong>
                <select class="widefat" id="<?php echo $this->get_field_id('layout'); ?>" name="<?php echo $this->get_field_name('layout'); ?>">
                    <option value="onlyicon"<?php echo (isset($instance['layout']) && $instance['layout'] == 'onlyicon')? ' selected="selected"' : '' ?>><?php _e('Only Icon', 'karp') ?></option>
                    <option value="iconwithtext"<?php echo (isset($instance['layout']) && $instance['layout'] == 'iconwithtext')? ' selected="selected"' : '' ?>><?php _e('Icon with Text', 'karp') ?></option>
                </select>
            </label>
        </p>
    <?php
    }
}
?>