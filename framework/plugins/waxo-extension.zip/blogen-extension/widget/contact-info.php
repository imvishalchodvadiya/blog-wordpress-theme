<?php
add_action('widgets_init', 'blogen_contact_info_load_widgets');

function blogen_contact_info_load_widgets() {
    register_widget('Blogen_Contact_Info_Widget');
}

class Blogen_Contact_Info_Widget extends WP_Widget {

    public function __construct() {

        $widget_ops = array('classname' => 'blogen_contact_info', 'description' => __('Add contact information.', 'blogen'));

        $control_ops = array('id_base' => 'blogen-contact-info-widget');

        parent::__construct('blogen-contact-info-widget', __('Blogen: Contact Info', 'blogen'), $widget_ops, $control_ops);
    }

    function widget($args, $instance) {
        extract($args);
        $title = apply_filters('widget_title', $instance['title']);
        $contact_before = $instance['contact_before'];
        $address = $instance['address'];
        $phone = $instance['phone'];
        $email = $instance['email'];
        $website = $instance['website'];
        $time = $instance['time'];
        $contact_after = $instance['contact_after'];

        echo $before_widget;

        if ($title) {
            echo $before_title . $title . $after_title;
        }
        ?>
        <div class="contact-widget">
            <?php if ($contact_before) : ?><?php echo wpautop(do_shortcode($contact_before)) ?><?php endif; ?>
            <ul class="list-group list-group-flush">
                <?php if ($address) : ?><li class="list-group-item"><i class="mdi mdi-map"></i><?php echo force_balance_tags($address); ?></li><?php endif; ?>
                <?php if ($phone) : ?><li class="list-group-item"><i class="mdi mdi-phone"></i><?php echo force_balance_tags($phone); ?></li><?php endif; ?>                
                <?php if ($email) : ?><li class="list-group-item"><i class="mdi mdi-email"></i><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo force_balance_tags($email); ?></a></li><?php endif; ?>
                <?php if ($website) : ?><li class="list-group-item"><i class="mdi mdi-web"></i><a href="<?php echo esc_url($website); ?>"><?php echo force_balance_tags($website); ?></a></li><?php endif; ?>
                <?php if ($time) : ?><li class="list-group-item"><i class="mdi mdi-timer"></i><?php echo force_balance_tags($time); ?></a></li><?php endif; ?>
            </ul>
            <?php if ($contact_after) : ?><?php echo wpautop(do_shortcode($contact_after)); ?><?php endif; ?>
        </div>

        <?php
        echo $after_widget;
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;

        $instance['title'] = strip_tags($new_instance['title']);
        $instance['contact_before'] = $new_instance['contact_before'];
        $instance['address'] = $new_instance['address'];
        $instance['phone'] = $new_instance['phone'];
        $instance['email'] = $new_instance['email'];
        $instance['website'] = $new_instance['website'];
        $instance['time'] = $new_instance['time'];
        $instance['contact_after'] = $new_instance['contact_after'];

        return $instance;
    }

    function form($instance) {
        $defaults = array('title' => __('Contact Us', 'blogen'), 'contact_before' => '', 'address_label' => '', 'address' => '1234 Street, City, Country', 'phone_label' => '', 'phone' => '(123) 456-7890', 'email_label' => '', 'email' => 'mail@example.com', 'website_label' => '', 'website' => 'www.xpanthersolutions.com', 'time' => 'Mon - Sun / 9:00 AM - 8:00 PM', 'contact_after' => '', 'view' => 'inline', 'icon' => '');
        $instance = wp_parse_args((array) $instance, $defaults); ?>

        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <strong><?php echo __('Title', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php if (isset($instance['title'])) echo $instance['title']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('contact_before'); ?>">
                <strong><?php echo __('Before Description', 'blogen') ?>:</strong>
                <textarea class="widefat" id="<?php echo $this->get_field_id('contact_before'); ?>" name="<?php echo $this->get_field_name('contact_before'); ?>"><?php if (isset($instance['contact_before'])) echo $instance['contact_before']; ?></textarea>
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('address'); ?>">
                <strong><?php echo __('Address', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('address'); ?>" name="<?php echo $this->get_field_name('address'); ?>" value="<?php if (isset($instance['address'])) echo $instance['address']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('phone'); ?>">
                <strong><?php echo __('Phone', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('phone'); ?>" name="<?php echo $this->get_field_name('phone'); ?>" value="<?php if (isset($instance['phone'])) echo $instance['phone']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('email'); ?>">
                <strong><?php echo __('Email', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" value="<?php if (isset($instance['email'])) echo $instance['email']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('website'); ?>">
                <strong><?php echo __('Website Name', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('website'); ?>" name="<?php echo $this->get_field_name('website'); ?>" value="<?php if (isset($instance['website'])) echo $instance['website']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('time'); ?>">
                <strong><?php echo __('Time', 'blogen') ?>:</strong>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('time'); ?>" name="<?php echo $this->get_field_name('time'); ?>" value="<?php if (isset($instance['time'])) echo $instance['time']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('contact_after'); ?>">
                <strong><?php echo __('After Description', 'blogen') ?>:</strong>
                <textarea class="widefat" id="<?php echo $this->get_field_id('contact_after'); ?>" name="<?php echo $this->get_field_name('contact_after'); ?>"><?php if (isset($instance['contact_after'])) echo $instance['contact_after']; ?></textarea>
            </label>
        </p>

    <?php
    }
}
?>