<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function portfolio_custom_post_type() {

    $labels = array(
        'name'               => esc_html__( 'Portfolios' , 'blogen' ),
        'singular_name'      => esc_html__( 'Portfolio' , 'blogen' ),
        'add_new'            => esc_html__( 'Add New' , 'blogen' ),
        'add_new_item'       => esc_html__( 'Add New Portfolio' , 'blogen' ),
        'edit_item'          => esc_html__( 'Edit Portfolio' , 'blogen' ),
        'new_item'           => esc_html__( 'New Portfolio' , 'blogen' ),
        'all_items'          => esc_html__( 'All Portfolio' , 'blogen' ),
        'view_item'          => esc_html__( 'View Portfolio' , 'blogen' ),
        'search_items'       => esc_html__( 'Search Portfolios' , 'blogen' ),
        'not_found'          => esc_html__( 'No products found' , 'blogen' ),
        'not_found_in_trash' => esc_html__( 'No products found in the Trash' , 'blogen' ),
        'parent_item_colon'  => '',
        'menu_name'          => esc_html__('Portfolios','blogen')
    );
    $args = array(
        'labels'        => $labels,
        'description'   => esc_html('Holds our portfolios and portfolio specific data','blogen'),
        'public'        => true,
        'supports'      => array( 'title', 'editor', 'author', 'thumbnail', 'sticky', 'comments', 'excerpt' ),
        'has_archive'   => true,
        'menu_icon'		=> 'dashicons-portfolio',
    );
		
    register_post_type( 'portfolio', $args );
}
add_action( 'init', 'portfolio_custom_post_type' );

function portfolio_custom_post_taxonomies() {
	
    $labels = array(
        'name'              => esc_html__( 'Portfolio Categories', 'blogen' ),
        'singular_name'     => esc_html__( 'Portfolio Category', 'blogen' ),
        'search_items'      => esc_html__( 'Search Portfolio Categories', 'blogen' ),
        'all_items'         => esc_html__( 'All Portfolio Categories', 'blogen' ),
        'parent_item'       => esc_html__( 'Parent Portfolio Category', 'blogen' ),
        'parent_item_colon' => esc_html__( 'Parent Portfolio Category:', 'blogen' ),
        'edit_item'         => esc_html__( 'Edit Portfolio Category', 'blogen' ),
        'update_item'       => esc_html__( 'Update Portfolio Category', 'blogen' ),
        'add_new_item'      => esc_html__( 'Add New Portfolio Category', 'blogen' ),
        'new_item_name'     => esc_html__( 'New Portfolio Category', 'blogen' ),
        'menu_name'         => esc_html__( 'Categories', 'blogen' ),
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,

    );
	
     register_taxonomy( 'portfolio_category', 'portfolio', $args );
}
add_action( 'init', 'portfolio_custom_post_taxonomies', 0 );

function portfolio_custom_post_tags() {
    $labels = array(
        'name'              => esc_html__( 'Portfolio Tags', 'blogen' ),
        'singular_name'     => esc_html__( 'Portfolio Tag', 'blogen' ),
        'search_items'      => esc_html__( 'Search Portfolio Tags', 'blogen' ),
        'all_items'         => esc_html__( 'All Portfolio Tags', 'blogen' ),
        'edit_item'         => esc_html__( 'Edit Portfolio Tag', 'blogen' ),
        'update_item'       => esc_html__( 'Update Portfolio Tag', 'blogen' ),
        'add_new_item'      => esc_html__( 'Add New Portfolio Tag', 'blogen' ),
        'new_item_name'     => esc_html__( 'New Portfolio Tag', 'blogen' ),
        'menu_name'         => esc_html__( 'Tags', 'blogen' ),
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => false,

    );
	register_taxonomy( 'portfolio_tags', 'portfolio', $args );
}
add_action( 'init', 'portfolio_custom_post_tags', 0 );