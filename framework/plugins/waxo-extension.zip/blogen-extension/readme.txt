===== Blogen Extension =====

Contributors: widget, custom post type

===== Description =====

Use for custom widget and custom post type for Blogen WordPress gradient personal blog theme

===== Installation =====

This is pretty simple. Follow the step below. Install through wordpress.org

1. Visit 'Plugins > Add New'
2. Search for 'blogen-extension'
3. Activate amira-extension from your Plugins page.

===== Manual install: =====

1. Upload `amira-extension.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place `<?php do_action('plugin_name_hook'); ?>` in your templates


===== Frequently Asked Questions =====

1. Can I use my existing WordPress theme? =====
	-	Yes, you can.

2. Will this work on WordPress multisite? =
	-	Yes, it will.

===== Changelog =====

= 1.0 =

* Initial Release.