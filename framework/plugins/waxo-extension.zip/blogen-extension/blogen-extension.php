<?php
/*
Plugin Name: Blogen Extension
Plugin URI: http://xpanthersolutions.com/wp/blogen
Description: A plugin to create custom post types, widgets etc...
Version: 1.0
Author: xpanthersolutions
Author URI: https://themeforest.net/user/xpanthersolutions
License: GPL
*/

include dirname(__FILE__) . '/widget/about-me.php';
include dirname(__FILE__) . '/widget/contact-info.php';
include dirname(__FILE__) . '/widget/social-widget.php';
include dirname(__FILE__) . '/widget/latest-post.php';
include dirname(__FILE__) . '/custom-post-type/portfolio.php';

function pluginprefix_install()
{
    // trigger our function that registers the custom post type
    portfolio_custom_post_type();
 
    // clear the permalinks after the post type has been registered
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'pluginprefix_install' );

return true;